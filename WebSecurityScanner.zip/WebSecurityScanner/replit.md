# AI Cybersecurity URL Threat Detector

## Overview

This is a Streamlit-based web application that uses machine learning to detect cybersecurity threats in URLs, specifically focusing on XSS (Cross-Site Scripting) and SQL Injection attacks. The application leverages scikit-learn for machine learning models, combined with pattern matching and URL analysis to provide comprehensive threat detection capabilities.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a modular architecture with clear separation of concerns:

- **Frontend**: Streamlit web interface for user interaction
- **ML Models**: RandomForest classifiers for XSS and SQL injection detection
- **Feature Engineering**: TF-IDF vectorization and custom feature extraction
- **Pattern Matching**: Regex-based pattern detection for known attack signatures
- **URL Analysis**: Comprehensive URL parsing and suspicious parameter detection

## Key Components

### 1. Main Application (app.py)
- **Purpose**: Entry point and UI controller
- **Technology**: Streamlit
- **Key Features**: 
  - Cached model loading for performance
  - Interactive threat detection interface
  - Configurable detection sensitivity
  - Real-time analysis capabilities

### 2. Threat Detection Model (models/threat_detector.py)
- **Purpose**: Core ML-based threat detection
- **Algorithm**: RandomForest classifiers with TF-IDF feature extraction
- **Features**:
  - Separate models for XSS and SQL injection detection
  - Feature extraction from URL components
  - Pre-compiled regex patterns for performance
  - Training capabilities with labeled datasets

### 3. Pattern Matching System (utils/patterns.py)
- **Purpose**: Rule-based threat detection using known attack patterns
- **Approach**: Comprehensive regex pattern libraries
- **Coverage**:
  - XSS patterns (script tags, event handlers, JavaScript protocols)
  - SQL injection patterns (UNION attacks, boolean-based attacks)
  - Encoding detection and evasion techniques

### 4. URL Analysis Engine (utils/url_analyzer.py)
- **Purpose**: Deep URL parsing and analysis
- **Capabilities**:
  - Complete URL component extraction
  - Query parameter analysis
  - Encoding detection (URL, HTML, Unicode, Hex)
  - Suspicious parameter identification
  - Fragment parameter parsing

### 5. Training Data (data/dataset_loader.py)
- **Purpose**: CSV dataset loader for training data
- **Content**: Real cybersecurity datasets with 2000+ samples each
- **Coverage**: XSS payloads and SQL injection attacks from security research

## Data Flow

1. **Input Processing**: User submits URL through Streamlit interface
2. **URL Parsing**: URLAnalyzer extracts and analyzes URL components
3. **Feature Extraction**: ThreatDetector converts URL to ML features using TF-IDF
4. **Pattern Matching**: PatternMatcher applies regex-based detection rules
5. **ML Prediction**: Trained models predict threat probability
6. **Result Aggregation**: Combine ML predictions with pattern matching results
7. **Output**: Display threat assessment with confidence scores and explanations

## External Dependencies

### Core ML Stack
- **scikit-learn**: Machine learning models and feature extraction
- **numpy**: Numerical computations
- **pandas**: Data manipulation and analysis

### Web Framework
- **streamlit**: Web application framework and UI components

### URL Processing
- **urllib.parse**: Built-in URL parsing capabilities
- **re**: Regex pattern matching (built-in)

### Encoding/Decoding
- **base64**: Base64 encoding/decoding (built-in)
- **html**: HTML entity handling (built-in)

## Deployment Strategy

### Local Development
- **Framework**: Streamlit development server
- **Performance**: Model caching with @st.cache_resource decorators
- **Configuration**: Sidebar-based sensitivity controls

### Production Considerations
- **Scalability**: Models are cached in memory for performance
- **Security**: No sensitive data persistence required
- **Dependencies**: All dependencies are standard Python packages
- **Resource Usage**: Moderate memory usage for model storage

### Key Architectural Decisions

1. **Hybrid Detection Approach**: Combines ML models with rule-based pattern matching for comprehensive coverage
   - **Rationale**: ML models catch novel attacks, patterns catch known signatures
   - **Trade-off**: Increased complexity for better detection accuracy

2. **Separate Models for Attack Types**: Individual models for XSS and SQL injection
   - **Rationale**: Different attack types have distinct characteristics
   - **Benefit**: Specialized detection with better accuracy per attack type

3. **TF-IDF Feature Extraction**: Text-based feature extraction for URL content
   - **Rationale**: Captures semantic patterns in attack payloads
   - **Alternative**: Character-level features were considered but provided less semantic understanding

4. **Streamlit Framework**: Choice of web framework for rapid prototyping
   - **Rationale**: Fast development, built-in caching, minimal setup
   - **Trade-off**: Less customization compared to Flask/Django

5. **CSV Dataset Integration**: Direct loading from data folder CSV files
   - **Rationale**: Simple data management without complex APIs
   - **Benefit**: Easy to add custom datasets, authentic security data usage

## Recent System Changes

### December 12, 2024 - Major Simplification Update
- **Removed risk scoring feature**: Eliminated complex risk calculations and scoring displays
- **Replaced training_patterns.py**: Created simplified CSV dataset loader (dataset_loader.py)
- **Added real cybersecurity datasets**: Downloaded authentic XSS (2000 samples) and SQL injection (2000 samples) datasets
- **Simplified data handling**: Direct CSV loading from data folder, no automatic downloading capability
- **Streamlined interface**: Focused on core threat detection without unnecessary complexity
- **Updated documentation**: Comprehensive PROJECT_REPORT.md reflecting current simplified architecture
- **Cleaned up files**: Removed unnecessary files and streamlined project structure