"""
AI Cybersecurity URL Threat Detector
A Streamlit application for detecting XSS and SQL injection attacks in URLs
"""

import streamlit as st
import pandas as pd
import numpy as np
from models.threat_detector import ThreatDetector
from utils.url_analyzer import URLAnalyzer
from utils.patterns import PatternMatcher

# Page configuration
st.set_page_config(
    page_title="AI Cybersecurity URL Threat Detector",
    page_icon="🛡️",
    layout="wide"
)

@st.cache_resource
def load_threat_detector():
    """Load and cache the threat detection model"""
    detector = ThreatDetector()
    detector.train_model()
    return detector

@st.cache_resource
def load_analyzers():
    """Load and cache URL analyzer and pattern matcher"""
    url_analyzer = URLAnalyzer()
    pattern_matcher = PatternMatcher()
    return url_analyzer, pattern_matcher

def main():
    st.title("🛡️ AI Cybersecurity URL Threat Detector")
    st.markdown("Detect XSS and SQL injection attacks in URLs using machine learning")
    
    # Load models and analyzers
    detector = load_threat_detector()
    url_analyzer, pattern_matcher = load_analyzers()
    
    # Simple configuration
    analysis_types = st.multiselect(
        "What to check for:",
        ["XSS Detection", "SQL Injection"],
        default=["XSS Detection", "SQL Injection"]
    )
    
    # Single URL analysis (main feature)
    st.subheader("Check a URL")
    
    url_input = st.text_input(
        "Enter URL:",
        placeholder="https://example.com/search?q=<script>alert('xss')</script>"
    )
    
    if st.button("🔍 Check URL", type="primary"):
        if url_input:
            if not analysis_types:
                st.error("Please select at least one detection type")
            else:
                with st.spinner("Checking URL..."):
                    detection_sensitivity = 0.5
                    results = analyze_single_url(url_input, detector, url_analyzer, pattern_matcher, analysis_types, detection_sensitivity)
                    display_simple_results(results)
        else:
            st.error("Please enter a URL")
    
    # Optional batch analysis (collapsed by default)
    with st.expander("Check Multiple URLs"):
        batch_urls = st.text_area(
            "Enter multiple URLs (one per line):",
            height=150,
            placeholder="https://example.com/page1\nhttps://example.com/page2"
        )
        
        if st.button("Check All URLs"):
            if batch_urls:
                if not analysis_types:
                    st.error("Please select at least one detection type")
                else:
                    urls_to_analyze = [url.strip() for url in batch_urls.split('\n') if url.strip()]
                    with st.spinner(f"Checking {len(urls_to_analyze)} URLs..."):
                        detection_sensitivity = 0.5
                        batch_results = analyze_batch_urls(urls_to_analyze, detector, url_analyzer, pattern_matcher, analysis_types, detection_sensitivity)
                        display_simple_batch_results(batch_results)
            else:
                st.error("Please enter URLs to check")

def analyze_single_url(url, detector, url_analyzer, pattern_matcher, analysis_types, sensitivity):
    """Analyze a single URL for security threats"""
    results = {
        'url': url,
        'parsed_url': url_analyzer.parse_url(url),
        'threats': [],
        'analysis_details': {}
    }
    
    # XSS Detection
    if "XSS Detection" in analysis_types:
        xss_result = detector.detect_xss(url, threshold=sensitivity)
        if xss_result['is_threat']:
            results['threats'].append('XSS')
        results['analysis_details']['xss'] = xss_result
    
    # SQL Injection Detection
    if "SQL Injection" in analysis_types:
        sql_result = detector.detect_sql_injection(url, threshold=sensitivity)
        if sql_result['is_threat']:
            results['threats'].append('SQL Injection')
        results['analysis_details']['sql'] = sql_result
    
    return results

def analyze_batch_urls(urls, detector, url_analyzer, pattern_matcher, analysis_types, sensitivity):
    """Analyze multiple URLs for security threats"""
    results = []
    progress_bar = st.progress(0)
    
    for i, url in enumerate(urls):
        try:
            result = analyze_single_url(url, detector, url_analyzer, pattern_matcher, analysis_types, sensitivity)
            results.append(result)
        except Exception as e:
            results.append({
                'url': url,
                'error': str(e),
                'threats': []
            })
        
        # Update progress
        progress_bar.progress((i + 1) / len(urls))
    
    return results

def display_simple_results(results):
    """Display simplified results for single URL analysis"""
    # Main threat summary
    col1, col2 = st.columns(2)
    
    with col1:
        threat_count = len(results['threats'])
        if threat_count == 0:
            st.success("✅ No threats detected")
        else:
            st.error(f"⚠️ {threat_count} threat(s) detected")
    
    with col2:
        if results['threats']:
            st.error("Threat Level: High")
        else:
            st.success("Threat Level: None")
    
    # Show detected threats
    if results['threats']:
        st.write("**Detected Threats:**")
        for threat in results['threats']:
            st.write(f"• {threat}")
    
    # Show analysis details in expander
    with st.expander("Analysis Details"):
        for analysis_type, details in results['analysis_details'].items():
            if details:
                st.write(f"**{analysis_type.upper()}:**")
                if isinstance(details, dict) and 'confidence' in details:
                    st.write(f"- Confidence: {details['confidence']:.2f}")
                    if 'pattern_score' in details:
                        st.write(f"- Pattern Score: {details['pattern_score']:.2f}")
                    if 'ml_score' in details:
                        st.write(f"- ML Score: {details['ml_score']:.2f}")
                    if 'detected_patterns' in details and details['detected_patterns']:
                        st.write(f"- Found patterns: {', '.join(details['detected_patterns'])}")
                    if 'is_threat' in details:
                        st.write(f"- Is Threat: {details['is_threat']}")

def display_simple_batch_results(results):
    """Display simplified results for batch URL analysis"""
    total_urls = len(results)
    threatened_urls = len([r for r in results if r.get('threats', [])])
    
    # Summary
    col1, col2 = st.columns(2)
    with col1:
        st.metric("Total URLs", total_urls)
    with col2:
        st.metric("Threats Found", threatened_urls)
    
    # Results list
    for i, result in enumerate(results, 1):
        threats = result.get('threats', [])
        
        if threats:
            st.error(f"{i}. {result['url']} - {', '.join(threats)}")
        else:
            st.success(f"{i}. {result['url']} - Safe")

if __name__ == "__main__":
    main()