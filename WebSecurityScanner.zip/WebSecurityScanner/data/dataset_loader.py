"""
Simple CSV dataset loader for cybersecurity training data
Loads XSS and SQL injection datasets from CSV files in data folder
"""


import pandas as pd
import os

def load_csv_data():
    """
    Load cybersecurity datasets from CSV files in data folder
    Returns processed training data for ML models
    """
    data_dir = "data"
    
    # CSV file paths
    xss_file = os.path.join(data_dir, "xss_dataset.csv")
    sql_file = os.path.join(data_dir, "sql_dataset.csv")
    
    # Check if files exist
    if not os.path.exists(xss_file) or not os.path.exists(sql_file):
        print("CSV datasets not found. Please download them to the data folder.")
        return create_fallback_dataset()
    
    try:
        # Load XSS dataset
        xss_df = pd.read_csv(xss_file)
        if 'payload' in xss_df.columns and 'label' in xss_df.columns:
            xss_urls = xss_df['payload'].astype(str).tolist()
            xss_labels = xss_df['label'].tolist()
        else:
            # Handle different column formats
            xss_urls = xss_df.iloc[:, 0].astype(str).tolist()
            if len(xss_df.columns) > 1:
                xss_labels = xss_df.iloc[:, 1].tolist()
            else:
                xss_labels = [1] * len(xss_urls)
        
        # Load SQL dataset  
        sql_df = pd.read_csv(sql_file)
        if 'payload' in sql_df.columns and 'label' in sql_df.columns:
            sql_urls = sql_df['payload'].astype(str).tolist()
            sql_labels = sql_df['label'].tolist()
        else:
            # Handle different column formats
            sql_urls = sql_df.iloc[:, 0].astype(str).tolist()
            if len(sql_df.columns) > 1:
                sql_labels = sql_df.iloc[:, 1].tolist()
            else:
                sql_labels = [1] * len(sql_urls)
        
        print(f"Loaded XSS dataset: {len(xss_urls)} samples")
        print(f"Loaded SQL dataset: {len(sql_urls)} samples")
        
        return {
            'xss': {'urls': xss_urls, 'labels': xss_labels},
            'sql': {'urls': sql_urls, 'labels': sql_labels}
        }
        
    except Exception as e:
        print(f"Error loading CSV data: {e}")
        return create_fallback_dataset()

def create_fallback_dataset():
    """Create basic fallback dataset when CSV files not found"""
    safe_urls = [
        "https://example.com/search?q=hello",
        "https://example.com/page?id=123", 
        "https://example.com/user?name=john",
        "https://example.com/product?category=electronics",
        "https://example.com/blog?post=latest-news",
        "https://example.com/contact?subject=inquiry",
        "https://example.com/search?term=python+programming",
        "https://example.com/api/data?format=json",
        "https://example.com/login?redirect=/dashboard",
        "https://example.com/gallery?image=sunset.jpg"
    ]
    
    xss_malicious = [
        "https://example.com/search?q=<script>alert('xss')</script>",
        "https://example.com/page?id=<script>alert(1)</script>",
        "https://example.com/user?name=<img src=x onerror=alert(1)>",
        "https://example.com/search?q=javascript:alert('xss')",
        "https://example.com/page?data=<iframe src=javascript:alert(1)></iframe>",
        "https://example.com/test?input=<svg onload=alert(1)>",
        "https://example.com/search?q=<script>document.cookie</script>",
        "https://example.com/page?id=<body onload=alert(1)>",
        "https://example.com/user?name=<script>window.location='http://evil.com'</script>",
        "https://example.com/search?q=<img src=x onerror=eval(atob('YWxlcnQoMSk='))>"
    ]
    
    sql_malicious = [
        "https://example.com/products?id=1' OR '1'='1",
        "https://example.com/users?id=1; DROP TABLE users; --",
        "https://example.com/search?q=1' UNION SELECT password FROM users --",
        "https://example.com/products?id=1' AND 1=1 --",
        "https://example.com/users?name=admin'--",
        "https://example.com/search?q=' OR 1=1#",
        "https://example.com/products?id=1' UNION ALL SELECT user(),version(),database() --",
        "https://example.com/users?id=1'; INSERT INTO users VALUES('hacker','pass'); --",
        "https://example.com/search?q=1' AND SLEEP(5) --",
        "https://example.com/products?id=1' OR SUBSTRING(user(),1,1)='a' --"
    ]
    
    xss_urls = safe_urls + xss_malicious
    xss_labels = [0] * len(safe_urls) + [1] * len(xss_malicious)
    
    sql_urls = safe_urls + sql_malicious
    sql_labels = [0] * len(safe_urls) + [1] * len(sql_malicious)
    
    return {
        'xss': {'urls': xss_urls, 'labels': xss_labels},
        'sql': {'urls': sql_urls, 'labels': sql_labels}
    }

def get_training_data():
    """
    Main function to get training data from CSV files
    Returns dictionaries with URLs and corresponding labels (0 = safe, 1 = malicious)
    """
    try:
        data = load_csv_data()
        return data['xss'], data['sql']
    except Exception as e:
        print(f"Error loading training data: {e}")
        data = create_fallback_dataset()
        return data['xss'], data['sql']