import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score
import re
from urllib.parse import urlparse, parse_qs, unquote
from data.dataset_loader import get_training_data

class ThreatDetector:
    """AI-powered threat detection for URLs using machine learning"""
    
    def __init__(self):
        self.xss_model = None
        self.sql_model = None
        self.vectorizer_xss = TfidfVectorizer(max_features=1000, ngram_range=(1, 3))
        self.vectorizer_sql = TfidfVectorizer(max_features=1000, ngram_range=(1, 3))
        self.is_trained = False
        
        # Compile regex patterns for better performance
        self.xss_patterns = [
            re.compile(r'<script[^>]*>.*?</script>', re.IGNORECASE | re.DOTALL),
            re.compile(r'javascript:', re.IGNORECASE),
            re.compile(r'on\w+\s*=', re.IGNORECASE),
            re.compile(r'<.*?on\w+.*?>', re.IGNORECASE),
            re.compile(r'eval\s*\(', re.IGNORECASE),
            re.compile(r'expression\s*\(', re.IGNORECASE),
            re.compile(r'vbscript:', re.IGNORECASE),
            re.compile(r'<iframe.*?>', re.IGNORECASE),
            re.compile(r'<object.*?>', re.IGNORECASE),
            re.compile(r'<embed.*?>', re.IGNORECASE)
        ]
        
        self.sql_patterns = [
            re.compile(r'\bunion\b.*\bselect\b', re.IGNORECASE),
            re.compile(r'\bselect\b.*\bfrom\b', re.IGNORECASE),
            re.compile(r'\binsert\b.*\binto\b', re.IGNORECASE),
            re.compile(r'\bupdate\b.*\bset\b', re.IGNORECASE),
            re.compile(r'\bdelete\b.*\bfrom\b', re.IGNORECASE),
            re.compile(r'\bdrop\b.*\btable\b', re.IGNORECASE),
            re.compile(r';\s*drop\b', re.IGNORECASE),
            re.compile(r"'\s*or\s+.*?\s*=\s*'", re.IGNORECASE),
            re.compile(r"'\s*and\s+.*?\s*=\s*'", re.IGNORECASE),
            re.compile(r'\b1\s*=\s*1\b', re.IGNORECASE),
            re.compile(r"'\s*or\s+1\s*=\s*1", re.IGNORECASE)
        ]
    
    def extract_features(self, url):
        """Extract features from URL for ML model"""
        try:
            # Decode URL multiple times to handle multiple encoding
            decoded_url = self._multi_decode(url)
            
            features = {
                'url_length': len(url),
                'decoded_length': len(decoded_url),
                'param_count': len(parse_qs(urlparse(url).query)),
                'special_char_count': len(re.findall(r'[<>"\';(){}]', decoded_url)),
                'script_count': len(re.findall(r'script', decoded_url, re.IGNORECASE)),
                'sql_keyword_count': self._count_sql_keywords(decoded_url),
                'has_javascript': int('javascript:' in decoded_url.lower()),
                'has_data_url': int('data:' in decoded_url.lower()),
                'encoding_layers': self._count_encoding_layers(url),
                'suspicious_chars': len(re.findall(r'[%+]', url)),
                'domain_suspicious': self._is_suspicious_domain(url)
            }
            
            return features
            
        except Exception as e:
            # Return default features if extraction fails
            return {
                'url_length': len(url),
                'decoded_length': len(url),
                'param_count': 0,
                'special_char_count': 0,
                'script_count': 0,
                'sql_keyword_count': 0,
                'has_javascript': 0,
                'has_data_url': 0,
                'encoding_layers': 0,
                'suspicious_chars': 0,
                'domain_suspicious': 0
            }
    
    def _multi_decode(self, url, max_iterations=5):
        """Decode URL multiple times to handle multiple encoding layers"""
        decoded = url
        for _ in range(max_iterations):
            try:
                new_decoded = unquote(decoded)
                if new_decoded == decoded:
                    break
                decoded = new_decoded
            except:
                break
        return decoded
    
    def _count_encoding_layers(self, url):
        """Count how many encoding layers the URL has"""
        count = 0
        decoded = url
        for _ in range(10):  # Max 10 layers
            try:
                new_decoded = unquote(decoded)
                if new_decoded == decoded:
                    break
                decoded = new_decoded
                count += 1
            except:
                break
        return count
    
    def _count_sql_keywords(self, text):
        """Count SQL keywords in text"""
        sql_keywords = ['select', 'union', 'insert', 'update', 'delete', 'drop', 'create', 'alter', 'exec', 'execute']
        count = 0
        text_lower = text.lower()
        for keyword in sql_keywords:
            count += len(re.findall(r'\b' + keyword + r'\b', text_lower))
        return count
    
    def _is_suspicious_domain(self, url):
        """Check if domain appears suspicious"""
        try:
            domain = urlparse(url).netloc.lower()
            suspicious_indicators = ['bit.ly', 'tinyurl', 'localhost', '127.0.0.1', 'xss', 'sqli']
            return int(any(indicator in domain for indicator in suspicious_indicators))
        except:
            return 0
    
    def train_model(self):
        """Train the machine learning models"""
        try:
            # Get training data
            xss_data, sql_data = get_training_data()
            
            # Train XSS model
            if xss_data['urls']:
                self._train_xss_model(xss_data['urls'], xss_data['labels'])
            
            # Train SQL injection model
            if sql_data['urls']:
                self._train_sql_model(sql_data['urls'], sql_data['labels'])
            
            self.is_trained = True
            
        except Exception as e:
            print(f"Error training models: {e}")
            # Initialize with default models
            self.xss_model = RandomForestClassifier(n_estimators=100, random_state=42)
            self.sql_model = RandomForestClassifier(n_estimators=100, random_state=42)
            
            # Create minimal training data for fallback
            dummy_urls = ['http://example.com', 'http://example.com/?q=<script>']
            dummy_labels = [0, 1]
            
            # Fit vectorizers and models with dummy data
            X_text = self.vectorizer_xss.fit_transform(dummy_urls)
            X_features = pd.DataFrame([self.extract_features(url) for url in dummy_urls])
            
            self.xss_model.fit(np.hstack([X_text.toarray(), X_features.values]), dummy_labels)
            
            X_text_sql = self.vectorizer_sql.fit_transform(dummy_urls)
            self.sql_model.fit(np.hstack([X_text_sql.toarray(), X_features.values]), dummy_labels)
            
            self.is_trained = True
    
    def _train_xss_model(self, urls, labels):
        """Train XSS detection model"""
        try:
            # Extract text features
            X_text = self.vectorizer_xss.fit_transform(urls)
            
            # Extract numerical features
            feature_dicts = [self.extract_features(url) for url in urls]
            X_features = pd.DataFrame(feature_dicts).fillna(0)
            
            # Combine features
            X_combined = np.hstack([X_text.toarray(), X_features.values])
            
            # Train model
            self.xss_model = RandomForestClassifier(n_estimators=100, random_state=42)
            self.xss_model.fit(X_combined, labels)
            
        except Exception as e:
            print(f"Error training XSS model: {e}")
    
    def _train_sql_model(self, urls, labels):
        """Train SQL injection detection model"""
        try:
            # Extract text features
            X_text = self.vectorizer_sql.fit_transform(urls)
            
            # Extract numerical features
            feature_dicts = [self.extract_features(url) for url in urls]
            X_features = pd.DataFrame(feature_dicts).fillna(0)
            
            # Combine features
            X_combined = np.hstack([X_text.toarray(), X_features.values])
            
            # Train model
            self.sql_model = RandomForestClassifier(n_estimators=100, random_state=42)
            self.sql_model.fit(X_combined, labels)
            
        except Exception as e:
            print(f"Error training SQL model: {e}")
    
    def detect_xss(self, url, threshold=0.5):
        """Detect XSS attacks in URL"""
        try:
            if not self.is_trained:
                self.train_model()
            
            # Pattern-based detection
            pattern_score = self._detect_xss_patterns(url)
            
            # ML-based detection
            ml_score = 0.0
            if self.xss_model is not None:
                try:
                    X_text = self.vectorizer_xss.transform([url])
                    X_features = pd.DataFrame([self.extract_features(url)]).fillna(0)
                    X_combined = np.hstack([X_text.toarray(), X_features.values])
                    
                    ml_prob = self.xss_model.predict_proba(X_combined)[0]
                    ml_score = ml_prob[1] if len(ml_prob) > 1 else 0.0
                except:
                    ml_score = 0.0
            
            # Combine scores
            final_score = max(pattern_score, ml_score)
            
            return {
                'is_threat': final_score >= threshold,
                'confidence': final_score,
                'pattern_score': pattern_score,
                'ml_score': ml_score,
                'detected_patterns': self._get_matched_xss_patterns(url)
            }
            
        except Exception as e:
            return {
                'is_threat': False,
                'confidence': 0.0,
                'error': str(e),
                'pattern_score': 0.0,
                'ml_score': 0.0,
                'detected_patterns': []
            }
    
    def detect_sql_injection(self, url, threshold=0.5):
        """Detect SQL injection attacks in URL"""
        try:
            if not self.is_trained:
                self.train_model()
            
            # Pattern-based detection
            pattern_score = self._detect_sql_patterns(url)
            
            # ML-based detection
            ml_score = 0.0
            if self.sql_model is not None:
                try:
                    X_text = self.vectorizer_sql.transform([url])
                    X_features = pd.DataFrame([self.extract_features(url)]).fillna(0)
                    X_combined = np.hstack([X_text.toarray(), X_features.values])
                    
                    ml_prob = self.sql_model.predict_proba(X_combined)[0]
                    ml_score = ml_prob[1] if len(ml_prob) > 1 else 0.0
                except:
                    ml_score = 0.0
            
            # Combine scores
            final_score = max(pattern_score, ml_score)
            
            return {
                'is_threat': final_score >= threshold,
                'confidence': final_score,
                'pattern_score': pattern_score,
                'ml_score': ml_score,
                'detected_patterns': self._get_matched_sql_patterns(url)
            }
            
        except Exception as e:
            return {
                'is_threat': False,
                'confidence': 0.0,
                'error': str(e),
                'pattern_score': 0.0,
                'ml_score': 0.0,
                'detected_patterns': []
            }
    
    def _detect_xss_patterns(self, url):
        """Detect XSS patterns and return confidence score"""
        decoded_url = self._multi_decode(url)
        matches = 0
        total_patterns = len(self.xss_patterns)
        
        for pattern in self.xss_patterns:
            if pattern.search(decoded_url):
                matches += 1
        
        return min(matches / total_patterns * 2, 1.0)  # Scale to 0-1
    
    def _detect_sql_patterns(self, url):
        """Detect SQL injection patterns and return confidence score"""
        decoded_url = self._multi_decode(url)
        matches = 0
        total_patterns = len(self.sql_patterns)
        
        for pattern in self.sql_patterns:
            if pattern.search(decoded_url):
                matches += 1
        
        return min(matches / total_patterns * 2, 1.0)  # Scale to 0-1
    
    def _get_matched_xss_patterns(self, url):
        """Get list of matched XSS patterns"""
        decoded_url = self._multi_decode(url)
        matched = []
        pattern_names = [
            'Script tags', 'JavaScript protocol', 'Event handlers', 'HTML with events',
            'Eval function', 'Expression function', 'VBScript protocol', 'Iframe tags',
            'Object tags', 'Embed tags'
        ]
        
        for i, pattern in enumerate(self.xss_patterns):
            if pattern.search(decoded_url):
                matched.append(pattern_names[i])
        
        return matched
    
    def _get_matched_sql_patterns(self, url):
        """Get list of matched SQL injection patterns"""
        decoded_url = self._multi_decode(url)
        matched = []
        pattern_names = [
            'UNION SELECT', 'SELECT FROM', 'INSERT INTO', 'UPDATE SET',
            'DELETE FROM', 'DROP TABLE', 'Semicolon DROP', 'OR condition',
            'AND condition', 'Tautology (1=1)', 'Quote manipulation'
        ]
        
        for i, pattern in enumerate(self.sql_patterns):
            if pattern.search(decoded_url):
                matched.append(pattern_names[i])
        
        return matched
