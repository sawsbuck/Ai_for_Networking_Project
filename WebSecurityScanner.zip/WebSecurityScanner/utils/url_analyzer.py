import re
from urllib.parse import urlparse, parse_qs, unquote, quote
import base64
import html

class URLAnalyzer:
    """Comprehensive URL analysis and parsing utilities"""
    
    def __init__(self):
        # Common encoding patterns
        self.encoding_patterns = {
            'url_encoding': re.compile(r'%[0-9A-Fa-f]{2}'),
            'html_entities': re.compile(r'&[a-zA-Z]+;|&#[0-9]+;|&#x[0-9A-Fa-f]+;'),
            'unicode_escape': re.compile(r'\\u[0-9A-Fa-f]{4}'),
            'hex_encoding': re.compile(r'\\x[0-9A-Fa-f]{2}'),
            'double_encoding': re.compile(r'%25[0-9A-Fa-f]{2}')
        }
    
    def parse_url(self, url):
        """Parse URL into components and extract detailed information"""
        try:
            parsed = urlparse(url)
            
            # Parse query parameters
            params = parse_qs(parsed.query, keep_blank_values=True)
            
            # Extract fragments
            fragment_params = {}
            if parsed.fragment:
                if '?' in parsed.fragment:
                    fragment_query = parsed.fragment.split('?', 1)[1]
                    fragment_params = parse_qs(fragment_query, keep_blank_values=True)
            
            result = {
                'scheme': parsed.scheme,
                'netloc': parsed.netloc,
                'path': parsed.path,
                'params': parsed.params,
                'query': parsed.query,
                'fragment': parsed.fragment,
                'username': parsed.username,
                'password': parsed.password,
                'hostname': parsed.hostname,
                'port': parsed.port,
                'query_params': params,
                'fragment_params': fragment_params,
                'param_count': len(params),
                'total_params': len(params) + len(fragment_params),
                'has_suspicious_params': self._check_suspicious_params(params),
                'url_length': len(url)
            }
            
            return result
            
        except Exception as e:
            return {
                'error': str(e),
                'url': url,
                'valid': False
            }
    
    def decode_and_analyze(self, url):
        """Decode URL through multiple layers and analyze encoding patterns"""
        try:
            analysis = {
                'original_url': url,
                'decoded_layers': [],
                'encoding_types': [],
                'final_decoded': url,
                'encoding_depth': 0,
                'suspicious_encoding': False
            }
            
            current_url = url
            max_iterations = 10
            
            for i in range(max_iterations):
                # Track the current state
                layer_info = {
                    'iteration': i + 1,
                    'input': current_url,
                    'output': None,
                    'encoding_detected': []
                }
                
                # Detect encoding types in current layer
                detected_encodings = self._detect_encoding_types(current_url)
                layer_info['encoding_detected'] = detected_encodings
                analysis['encoding_types'].extend(detected_encodings)
                
                # Try different decoding methods
                decoded_url = self._decode_layer(current_url)
                layer_info['output'] = decoded_url
                
                analysis['decoded_layers'].append(layer_info)
                
                # If no change, we're done
                if decoded_url == current_url:
                    break
                
                current_url = decoded_url
                analysis['encoding_depth'] += 1
            
            analysis['final_decoded'] = current_url
            analysis['suspicious_encoding'] = analysis['encoding_depth'] > 2
            
            # Analyze the final decoded URL
            analysis['final_analysis'] = self._analyze_decoded_content(current_url)
            
            return analysis
            
        except Exception as e:
            return {
                'error': str(e),
                'original_url': url
            }
    
    def _detect_encoding_types(self, text):
        """Detect types of encoding present in the text"""
        detected = []
        
        for encoding_type, pattern in self.encoding_patterns.items():
            if pattern.search(text):
                detected.append(encoding_type)
        
        # Check for base64 encoding
        if self._is_base64_encoded(text):
            detected.append('base64')
        
        return detected
    
    def _decode_layer(self, text):
        """Decode one layer of encoding"""
        try:
            # URL decoding
            url_decoded = unquote(text)
            if url_decoded != text:
                return url_decoded
            
            # HTML entity decoding
            html_decoded = html.unescape(text)
            if html_decoded != text:
                return html_decoded
            
            # Unicode escape decoding
            try:
                unicode_decoded = text.encode().decode('unicode_escape')
                if unicode_decoded != text:
                    return unicode_decoded
            except:
                pass
            
            # Base64 decoding (if it looks like base64)
            if self._is_base64_encoded(text):
                try:
                    base64_decoded = base64.b64decode(text).decode('utf-8', errors='ignore')
                    if base64_decoded != text:
                        return base64_decoded
                except:
                    pass
            
            return text
            
        except Exception:
            return text
    
    def _is_base64_encoded(self, text):
        """Check if text might be base64 encoded"""
        if len(text) < 4 or len(text) % 4 != 0:
            return False
        
        # Check if it contains only base64 characters
        base64_pattern = re.compile(r'^[A-Za-z0-9+/]*={0,2}$')
        return bool(base64_pattern.match(text))
    
    def _analyze_decoded_content(self, content):
        """Analyze the final decoded content for suspicious patterns"""
        analysis = {
            'length': len(content),
            'contains_html': bool(re.search(r'<[^>]+>', content)),
            'contains_javascript': 'javascript:' in content.lower(),
            'contains_script_tags': bool(re.search(r'<script[^>]*>', content, re.IGNORECASE)),
            'contains_sql_keywords': self._contains_sql_keywords(content),
            'special_char_count': len(re.findall(r'[<>"\';(){}]', content)),
            'suspicious_functions': self._find_suspicious_functions(content)
        }
        
        return analysis
    
    def _contains_sql_keywords(self, content):
        """Check if content contains SQL keywords"""
        sql_keywords = ['select', 'union', 'insert', 'update', 'delete', 'drop', 'create', 'alter']
        content_lower = content.lower()
        
        found_keywords = []
        for keyword in sql_keywords:
            if re.search(r'\b' + keyword + r'\b', content_lower):
                found_keywords.append(keyword)
        
        return found_keywords
    
    def _find_suspicious_functions(self, content):
        """Find suspicious JavaScript functions"""
        suspicious_functions = ['eval', 'setTimeout', 'setInterval', 'Function', 'alert', 'confirm', 'prompt']
        content_lower = content.lower()
        
        found_functions = []
        for func in suspicious_functions:
            if re.search(r'\b' + func + r'\s*\(', content_lower):
                found_functions.append(func)
        
        return found_functions
    
    def _check_suspicious_params(self, params):
        """Check if URL parameters contain suspicious content"""
        suspicious_indicators = []
        
        for param_name, param_values in params.items():
            for value in param_values:
                # Check for common XSS patterns
                if re.search(r'<script|javascript:|on\w+\s*=', value, re.IGNORECASE):
                    suspicious_indicators.append(f'XSS pattern in {param_name}')
                
                # Check for SQL injection patterns
                if re.search(r'\bunion\b.*\bselect\b|\'.*or.*\'|\'.*and.*\'', value, re.IGNORECASE):
                    suspicious_indicators.append(f'SQL injection pattern in {param_name}')
                
                # Check for unusual encoding
                if value.count('%') > len(value) * 0.1:  # More than 10% encoded
                    suspicious_indicators.append(f'Heavy encoding in {param_name}')
        
        return suspicious_indicators
    
    def normalize_url(self, url):
        """Normalize URL by decoding and cleaning"""
        try:
            # Decode multiple layers
            decode_result = self.decode_and_analyze(url)
            normalized = decode_result['final_decoded']
            
            # Parse and reconstruct
            parsed = urlparse(normalized)
            
            # Normalize components
            scheme = parsed.scheme.lower() if parsed.scheme else 'http'
            netloc = parsed.netloc.lower() if parsed.netloc else ''
            path = parsed.path if parsed.path else '/'
            
            # Reconstruct normalized URL
            normalized_url = f"{scheme}://{netloc}{path}"
            
            if parsed.query:
                normalized_url += f"?{parsed.query}"
            
            if parsed.fragment:
                normalized_url += f"#{parsed.fragment}"
            
            return {
                'original': url,
                'normalized': normalized_url,
                'changes_made': url != normalized_url
            }
            
        except Exception as e:
            return {
                'original': url,
                'normalized': url,
                'error': str(e)
            }
    
    def extract_payloads(self, url):
        """Extract potential attack payloads from URL"""
        try:
            parsed = self.parse_url(url)
            decoded = self.decode_and_analyze(url)
            
            payloads = {
                'xss_payloads': [],
                'sql_payloads': [],
                'other_payloads': []
            }
            
            # Check query parameters
            if 'query_params' in parsed:
                for param_name, param_values in parsed['query_params'].items():
                    for value in param_values:
                        payload_info = {
                            'parameter': param_name,
                            'value': value,
                            'type': self._classify_payload(value)
                        }
                        
                        if payload_info['type'] == 'xss':
                            payloads['xss_payloads'].append(payload_info)
                        elif payload_info['type'] == 'sql':
                            payloads['sql_payloads'].append(payload_info)
                        else:
                            payloads['other_payloads'].append(payload_info)
            
            # Check decoded content
            if 'final_decoded' in decoded:
                final_content = decoded['final_decoded']
                if final_content != url:
                    payload_type = self._classify_payload(final_content)
                    payload_info = {
                        'parameter': 'decoded_url',
                        'value': final_content,
                        'type': payload_type
                    }
                    
                    if payload_type == 'xss':
                        payloads['xss_payloads'].append(payload_info)
                    elif payload_type == 'sql':
                        payloads['sql_payloads'].append(payload_info)
                    else:
                        payloads['other_payloads'].append(payload_info)
            
            return payloads
            
        except Exception as e:
            return {
                'error': str(e),
                'xss_payloads': [],
                'sql_payloads': [],
                'other_payloads': []
            }
    
    def _classify_payload(self, payload):
        """Classify payload type based on content"""
        payload_lower = payload.lower()
        
        # XSS indicators
        xss_indicators = ['<script', 'javascript:', 'on', 'eval(', 'alert(', '<iframe', '<object']
        if any(indicator in payload_lower for indicator in xss_indicators):
            return 'xss'
        
        # SQL injection indicators
        sql_indicators = ['union', 'select', 'drop', 'insert', 'update', 'delete', "' or ", "' and "]
        if any(indicator in payload_lower for indicator in sql_indicators):
            return 'sql'
        
        return 'unknown'
