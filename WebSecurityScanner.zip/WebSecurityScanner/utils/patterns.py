import re
from urllib.parse import urlparse, parse_qs, unquote

class PatternMatcher:
    """Advanced pattern matching for cybersecurity threat detection"""
    
    def __init__(self):
        # XSS attack patterns
        self.xss_patterns = {
            'script_tags': [
                r'<script[^>]*>.*?</script>',
                r'<script[^>]*>',
                r'</script>',
                r'<script\s*>',
                r'<script/?>',
            ],
            'javascript_protocols': [
                r'javascript:',
                r'jAvAsCrIpT:',
                r'j\s*a\s*v\s*a\s*s\s*c\s*r\s*i\s*p\s*t\s*:',
            ],
            'event_handlers': [
                r'on\w+\s*=',
                r'onload\s*=',
                r'onerror\s*=',
                r'onclick\s*=',
                r'onmouseover\s*=',
                r'onfocus\s*=',
                r'onblur\s*=',
            ],
            'html_injection': [
                r'<iframe[^>]*>',
                r'<object[^>]*>',
                r'<embed[^>]*>',
                r'<form[^>]*>',
                r'<img[^>]*>',
                r'<svg[^>]*>',
            ],
            'javascript_functions': [
                r'eval\s*\(',
                r'setTimeout\s*\(',
                r'setInterval\s*\(',
                r'Function\s*\(',
                r'alert\s*\(',
                r'confirm\s*\(',
                r'prompt\s*\(',
            ],
            'data_urls': [
                r'data:text/html',
                r'data:image/svg\+xml',
                r'data:application',
            ],
            'css_injection': [
                r'expression\s*\(',
                r'behavior\s*:',
                r'@import',
                r'url\s*\(',
            ]
        }
        
        # SQL injection patterns
        self.sql_patterns = {
            'union_based': [
                r'\bunion\b.*\bselect\b',
                r'\bunion\b.*\bfrom\b',
                r'\bunion\b.*\ball\b.*\bselect\b',
            ],
            'boolean_based': [
                r"'\s*or\s*'1'\s*=\s*'1",
                r"'\s*or\s*1\s*=\s*1",
                r"'\s*and\s*'1'\s*=\s*'1",
                r"'\s*and\s*1\s*=\s*1",
                r'\bor\b.*1=1',
                r'\band\b.*1=1',
            ],
            'error_based': [
                r'extractvalue\s*\(',
                r'updatexml\s*\(',
                r'floor\s*\(.*rand\s*\(',
                r'count\s*\(.*group\s*by',
            ],
            'time_based': [
                r'sleep\s*\(',
                r'benchmark\s*\(',
                r'pg_sleep\s*\(',
                r'waitfor\s+delay',
            ],
            'stacked_queries': [
                r';\s*drop\b',
                r';\s*delete\b',
                r';\s*insert\b',
                r';\s*update\b',
                r';\s*create\b',
                r';\s*alter\b',
            ],
            'comment_injection': [
                r'/\*.*?\*/',
                r'--\s*',
                r'#.*',
                r'\s+--',
            ],
            'string_manipulation': [
                r"'\s*\+\s*'",
                r'concat\s*\(',
                r'char\s*\(',
                r'ascii\s*\(',
                r'substring\s*\(',
            ]
        }
        
        # Other attack patterns
        self.other_patterns = {
            'path_traversal': [
                r'\.\./.*\.\.',
                r'\.\.\\.*\.\.',
                r'%2e%2e%2f',
                r'%2e%2e\\',
            ],
            'command_injection': [
                r';\s*ls\b',
                r';\s*cat\b',
                r';\s*whoami\b',
                r';\s*id\b',
                r'`.*`',
                r'\$\(.*\)',
            ],
            'ldap_injection': [
                r'\*\)\(.*=',
                r'\)\(\|',
                r'\)\(&',
            ],
            'xpath_injection': [
                r"'\s*or\s*'.*'='",
                r"'\s*and\s*'.*'='",
            ]
        }
        
        # Compile all patterns for performance
        self.compiled_patterns = {}
        self._compile_patterns()
    
    def _compile_patterns(self):
        """Compile all regex patterns for better performance"""
        pattern_groups = [
            ('xss', self.xss_patterns),
            ('sql', self.sql_patterns),
            ('other', self.other_patterns)
        ]
        
        for group_name, patterns in pattern_groups:
            self.compiled_patterns[group_name] = {}
            for category, pattern_list in patterns.items():
                self.compiled_patterns[group_name][category] = [
                    re.compile(pattern, re.IGNORECASE | re.DOTALL)
                    for pattern in pattern_list
                ]
    
    def analyze_patterns(self, url):
        """Comprehensive pattern analysis of URL"""
        try:
            # Decode URL multiple times
            decoded_url = self._multi_decode(url)
            
            analysis = {
                'original_url': url,
                'decoded_url': decoded_url,
                'xss_analysis': self._analyze_xss_patterns(decoded_url),
                'sql_analysis': self._analyze_sql_patterns(decoded_url),
                'other_analysis': self._analyze_other_patterns(decoded_url),
                'overall_threat_score': 0,
                'threat_categories': []
            }
            
            # Calculate overall threat score
            xss_score = analysis['xss_analysis']['threat_score']
            sql_score = analysis['sql_analysis']['threat_score']
            other_score = analysis['other_analysis']['threat_score']
            
            analysis['overall_threat_score'] = max(xss_score, sql_score, other_score)
            
            # Determine threat categories
            if xss_score > 0.3:
                analysis['threat_categories'].append('XSS')
            if sql_score > 0.3:
                analysis['threat_categories'].append('SQL Injection')
            if other_score > 0.3:
                analysis['threat_categories'].append('Other Injection')
            
            return analysis
            
        except Exception as e:
            return {
                'error': str(e),
                'original_url': url,
                'threat_categories': [],
                'overall_threat_score': 0
            }
    
    def _analyze_xss_patterns(self, url):
        """Analyze XSS attack patterns"""
        analysis = {
            'threat_score': 0,
            'matched_categories': [],
            'matched_patterns': [],
            'pattern_details': {}
        }
        
        total_matches = 0
        total_categories = len(self.compiled_patterns['xss'])
        
        for category, patterns in self.compiled_patterns['xss'].items():
            matches = []
            for pattern in patterns:
                match = pattern.search(url)
                if match:
                    matches.append({
                        'pattern': pattern.pattern,
                        'match': match.group(),
                        'start': match.start(),
                        'end': match.end()
                    })
                    total_matches += 1
            
            if matches:
                analysis['matched_categories'].append(category)
                analysis['pattern_details'][category] = matches
                analysis['matched_patterns'].extend([m['pattern'] for m in matches])
        
        # Calculate threat score
        category_score = len(analysis['matched_categories']) / total_categories
        pattern_density = min(total_matches / 10, 1.0)  # Normalize to 0-1
        analysis['threat_score'] = min(category_score + pattern_density, 1.0)
        
        return analysis
    
    def _analyze_sql_patterns(self, url):
        """Analyze SQL injection patterns"""
        analysis = {
            'threat_score': 0,
            'matched_categories': [],
            'matched_patterns': [],
            'pattern_details': {}
        }
        
        total_matches = 0
        total_categories = len(self.compiled_patterns['sql'])
        
        for category, patterns in self.compiled_patterns['sql'].items():
            matches = []
            for pattern in patterns:
                match = pattern.search(url)
                if match:
                    matches.append({
                        'pattern': pattern.pattern,
                        'match': match.group(),
                        'start': match.start(),
                        'end': match.end()
                    })
                    total_matches += 1
            
            if matches:
                analysis['matched_categories'].append(category)
                analysis['pattern_details'][category] = matches
                analysis['matched_patterns'].extend([m['pattern'] for m in matches])
        
        # Calculate threat score
        category_score = len(analysis['matched_categories']) / total_categories
        pattern_density = min(total_matches / 10, 1.0)  # Normalize to 0-1
        analysis['threat_score'] = min(category_score + pattern_density, 1.0)
        
        return analysis
    
    def _analyze_other_patterns(self, url):
        """Analyze other attack patterns"""
        analysis = {
            'threat_score': 0,
            'matched_categories': [],
            'matched_patterns': [],
            'pattern_details': {}
        }
        
        total_matches = 0
        total_categories = len(self.compiled_patterns['other'])
        
        for category, patterns in self.compiled_patterns['other'].items():
            matches = []
            for pattern in patterns:
                match = pattern.search(url)
                if match:
                    matches.append({
                        'pattern': pattern.pattern,
                        'match': match.group(),
                        'start': match.start(),
                        'end': match.end()
                    })
                    total_matches += 1
            
            if matches:
                analysis['matched_categories'].append(category)
                analysis['pattern_details'][category] = matches
                analysis['matched_patterns'].extend([m['pattern'] for m in matches])
        
        # Calculate threat score
        if total_categories > 0:
            category_score = len(analysis['matched_categories']) / total_categories
        else:
            category_score = 0
        pattern_density = min(total_matches / 5, 1.0)  # Normalize to 0-1
        analysis['threat_score'] = min(category_score + pattern_density, 1.0)
        
        return analysis
    
    def _multi_decode(self, url, max_iterations=5):
        """Decode URL multiple times to handle multiple encoding layers"""
        decoded = url
        for _ in range(max_iterations):
            try:
                new_decoded = unquote(decoded)
                if new_decoded == decoded:
                    break
                decoded = new_decoded
            except:
                break
        return decoded
    
    def detect_evasion_techniques(self, url):
        """Detect evasion techniques used in the URL"""
        techniques = {
            'url_encoding': self._detect_url_encoding(url),
            'double_encoding': self._detect_double_encoding(url),
            'mixed_case': self._detect_mixed_case(url),
            'null_bytes': self._detect_null_bytes(url),
            'comment_evasion': self._detect_comment_evasion(url),
            'whitespace_evasion': self._detect_whitespace_evasion(url)
        }
        
        evasion_score = sum(1 for detected in techniques.values() if detected) / len(techniques)
        
        return {
            'techniques': techniques,
            'evasion_score': evasion_score,
            'highly_evasive': evasion_score > 0.5
        }
    
    def _detect_url_encoding(self, url):
        """Detect URL encoding usage"""
        encoded_chars = re.findall(r'%[0-9A-Fa-f]{2}', url)
        return len(encoded_chars) > 0
    
    def _detect_double_encoding(self, url):
        """Detect double URL encoding"""
        double_encoded = re.findall(r'%25[0-9A-Fa-f]{2}', url)
        return len(double_encoded) > 0
    
    def _detect_mixed_case(self, url):
        """Detect mixed case evasion"""
        # Look for patterns like jAvAsCrIpT or UnIoN
        suspicious_patterns = [
            r'j[aA][vV][aA][sS][cC][rR][iI][pP][tT]',
            r'u[nN][iI][oO][nN]',
            r's[eE][lL][eE][cC][tT]',
            r'a[lL][eE][rR][tT]'
        ]
        
        for pattern in suspicious_patterns:
            if re.search(pattern, url):
                return True
        return False
    
    def _detect_null_bytes(self, url):
        """Detect null byte injection"""
        null_patterns = [r'%00', r'\\x00', r'\\0']
        return any(re.search(pattern, url) for pattern in null_patterns)
    
    def _detect_comment_evasion(self, url):
        """Detect SQL comment evasion"""
        comment_patterns = [r'/\*.*?\*/', r'--', r'#']
        return any(re.search(pattern, url) for pattern in comment_patterns)
    
    def _detect_whitespace_evasion(self, url):
        """Detect whitespace evasion techniques"""
        # Look for encoded whitespace or unusual spacing
        whitespace_patterns = [r'%20', r'%09', r'%0a', r'%0d', r'\s{2,}']
        return any(re.search(pattern, url) for pattern in whitespace_patterns)
    
    def get_pattern_library(self):
        """Return information about available patterns"""
        library = {
            'xss_categories': list(self.xss_patterns.keys()),
            'sql_categories': list(self.sql_patterns.keys()),
            'other_categories': list(self.other_patterns.keys()),
            'total_patterns': 0
        }
        
        # Count total patterns
        for patterns in [self.xss_patterns, self.sql_patterns, self.other_patterns]:
            for pattern_list in patterns.values():
                library['total_patterns'] += len(pattern_list)
        
        return library
    
    def test_pattern(self, pattern, test_string):
        """Test a specific pattern against a string"""
        try:
            compiled_pattern = re.compile(pattern, re.IGNORECASE | re.DOTALL)
            match = compiled_pattern.search(test_string)
            
            if match:
                return {
                    'matched': True,
                    'match_text': match.group(),
                    'start_position': match.start(),
                    'end_position': match.end()
                }
            else:
                return {
                    'matched': False
                }
                
        except Exception as e:
            return {
                'error': str(e),
                'matched': False
            }
